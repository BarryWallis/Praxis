﻿namespace RpnCalculator.Model
{
    public enum RpnOperator
    {
        Add, Subtract, Multiply, Divide,
    }
}